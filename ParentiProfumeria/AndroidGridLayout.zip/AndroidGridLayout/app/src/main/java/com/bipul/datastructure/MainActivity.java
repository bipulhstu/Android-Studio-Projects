package com.bipul.datastructure;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import androidx.gridlayout.widget.GridLayout;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

//package for intent animation
import static maes.tech.intentanim.CustomIntent.customType;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private CardView basics, linkedList, stack, queue, recursion, sorting, searching, binaryTree, binarySearchTree, heap, hash, questions;
    Animation fromBottom, fromTop;

    GridLayout mainGrid;
    TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //grid layout
        mainGrid = (GridLayout) findViewById(R.id.mainGrid);

        title = (TextView) findViewById(R.id.titleTextViewId);

        //find all cardview
        basics = (CardView) findViewById(R.id.basicsCardViewId);
        linkedList = (CardView) findViewById(R.id.linkedListCardViewId);
        stack = (CardView) findViewById(R.id.stackCardViewId);
        queue = (CardView) findViewById(R.id.queueCardViewId);
        recursion = (CardView) findViewById(R.id.recursionCardViewId);
        sorting = (CardView) findViewById(R.id.sortingCardViewId);
        searching = (CardView) findViewById(R.id.searchingCardViewId);
        binaryTree = (CardView) findViewById(R.id.binaryTreeCardViewId);
        binarySearchTree = (CardView) findViewById(R.id.binarySearchTreeCardViewId);
        heap = (CardView) findViewById(R.id.heapCardViewId);
        hash = (CardView) findViewById(R.id.hashCardViewId);
        questions = (CardView) findViewById(R.id.questionsCardViewId);

        //find animation
        fromBottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);
        fromTop = AnimationUtils.loadAnimation(this, R.anim.fromtop);


        //start animation
        title.startAnimation(fromTop);
        basics.startAnimation(fromBottom);
        linkedList.startAnimation(fromBottom);
        stack.startAnimation(fromBottom);
        queue.startAnimation(fromBottom);
        recursion.startAnimation(fromBottom);
        sorting.startAnimation(fromBottom);
        searching.startAnimation(fromBottom);
        binaryTree.startAnimation(fromBottom);
        binarySearchTree.startAnimation(fromBottom);
        heap.startAnimation(fromBottom);
        hash.startAnimation(fromBottom);
        questions.startAnimation(fromBottom);

        basics.setOnClickListener(this);



    }


    @Override
    public void onClick(View v) {

        if(v.getId() == R.id.basicsCardViewId){
            Intent intent = new Intent(MainActivity.this, BasicsActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.linkedListCardViewId){
            Intent intent = new Intent(MainActivity.this, LinkedListActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.stackCardViewId){
            Intent intent = new Intent(MainActivity.this, StackActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.queueCardViewId){
            Intent intent = new Intent(MainActivity.this, QueueActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.recursionCardViewId){
            Intent intent = new Intent(MainActivity.this, RecursionActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }
        else if(v.getId() == R.id.sortingCardViewId){
            Intent intent = new Intent(MainActivity.this, SortingActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }
        else if(v.getId() == R.id.searchingCardViewId){
            Intent intent = new Intent(MainActivity.this, SearchingActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.binaryTreeCardViewId){
            Intent intent = new Intent(MainActivity.this, BinaryTreeActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }
        else if(v.getId() == R.id.binarySearchTreeCardViewId){
            Intent intent = new Intent(MainActivity.this, BinarySearchTreeActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }
        else if(v.getId() == R.id.heapCardViewId){
            Intent intent = new Intent(MainActivity.this, HeapActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.hashCardViewId){
            Intent intent = new Intent(MainActivity.this, HashActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }

        else if(v.getId() == R.id.questionsCardViewId){
            Intent intent = new Intent(MainActivity.this, QuestionsActivity.class);
            startActivity(intent);
            customType(MainActivity.this,"left-to-right");
            finish();
        }
    }
}
